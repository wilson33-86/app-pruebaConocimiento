<?php

require "models/usuario.php";
require "models/rol.php";
require "models/eps.php";

class LoginModel extends Model{

    function __construct()
     {   
         parent::__construct();
        //  $this->view->productos=[];
        
     }

     function autenticar($usuario,$password){
      $sentencia = $this->db->connect()->prepare('Select * from tb_usuarios  where nombre=? and password =?');
      $sentencia->execute([$usuario,$password]);
      $rows = $sentencia->rowCount();
   
      if($rows>0){
       return true;
      }else{
        return false;
      }

     }
     
     public function getUsuarios(){
       
      $data=[];

      $sentencia = $this->db->connect()->query("SELECT id, nombre, documento, genero, fecha_nacimiento, telefono, eps_id,rol_id FROM tb_usuarios");
   
      if($sentencia){
      while($row = $sentencia->fetch()){
          $dato = new UsuarioClass();
          $dato->id = $row['id'];
          $dato->nombre = $row['nombre'];
          $dato->documento = $row['documento'];
          $dato->genero = $row['genero'];
          $dato->edad = $row['fecha_nacimiento'];
          $dato->telefono = $row['telefono'];
          $dato->eps = $row['eps_id'];
          $dato->rol = $row['rol_id'];

          array_push($data,$dato);
          
      }
      return $data;
      }else{
          return [];

      }


  }

  function obtenerRoles(){
    $data=[];

    $sentencia = $this->db->connect()->query("SELECT * FROM tb_roles");
 
    if($sentencia){
    while($row = $sentencia->fetch()){
        $dato = new Rol();
        $dato->id = $row['id'];
        $dato->nombre = $row['nombre'];
     

        array_push($data,$dato);
        
    }
    return $data;
    }else{
        return [];

    }
  }

  function obtenerEps(){
    $data=[];

    $sentencia = $this->db->connect()->query("SELECT * FROM tb_eps");
 
    if($sentencia){
    while($row = $sentencia->fetch()){
        $dato = new Eps();
        $dato->id = $row['id'];
        $dato->nombre = $row['nombre'];
     

        array_push($data,$dato);
        
    }
    return $data;
    }else{
        return [];

    }
  }
    
  
  public function guardarUsuario($nombre,$documento,$password,$genero,$fechaN,$telefono,$eps,$rol){

    try{
        $sentencia = $this->db->connect()->prepare("INSERT INTO tb_usuarios(nombre, documento,password,genero,fecha_nacimiento,telefono,eps_id,rol_id) VALUES(?, ?, ?,?,?,?,?,?)");
        $sentencia->execute([$nombre, $documento,$password,$genero,$fechaN,$telefono,$eps,$rol]);
        return true;

    }catch(PDOException $e){
    echo $e->getMessage();
    return false;
     }   

}
  
function obtenerUsuarioId($id){

    $sentencia = $this->db->connect()->prepare("select * from tb_usuarios where id=?");
    $sentencia->execute([$id]);

    $rows= $sentencia->rowCount();
   
    if($rows>0){
        while($row = $sentencia->fetch()){
        $dato = new UsuarioClass();
        $dato->id = $row['id'];
        $dato->nombre = $row['nombre'];
        $dato->documento = $row['documento'];
        $dato->genero = $row['genero'];
        $dato->password = $row['password'];
        $dato->edad = $row['fecha_nacimiento'];
        $dato->telefono = $row['telefono'];
        $dato->eps = $row['eps_id'];
        $dato->rol = $row['rol_id'];

     return $dato;

    }}else{
      return [];
    }


}

function updateUsuario($id,$nombre,$documento,$password,$genero,$fechaN,$telefono,$rol,$eps){
   

    $sentencia =  $this->db->connect()->prepare("UPDATE tb_usuarios SET nombre = ?, documento = ?,password = ?,genero = ?,fecha_nacimiento = ?,telefono= ?,eps_id=?,rol_id=? WHERE id = ?");
   
    $sentencia->execute([$nombre,$documento,$password,$genero,$fechaN,$telefono,$eps,$rol,$id]);
     $rows = $sentencia->rowCount();
 
    if($rows>0){
      
        return true;
    }else{
       
        return false;
    }

}

public  function eliminarUsuario($id){
    $sentencia = $this->db->connect()->prepare("DELETE FROM tb_usuarios WHERE id = ?");
    return $sentencia->execute([$id]);
    if($sentencia){
      
            return true;
    }else{
           
            return false;
     }
}

    }
?>