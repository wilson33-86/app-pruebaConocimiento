<?php
class Rol{
 
    public $id;
    public $nombre;

}
?>