<?php
class UsuarioClass{
 
    public $nombre;
    public $documento;
    public $genero;
    public $password;
    public $edad;
    public $telefono;
    public $eps;
    public $rol;
}
?>

