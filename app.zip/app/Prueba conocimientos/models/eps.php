<?php
class Eps{
 
    public $id;
    public $nombre;

}
?>