<?php

class Login extends Controller{

    function __construct()
     {   
         parent::__construct();
         $this->view->usuarios=[];
        
     }
     
      function render($param = null){        
        
         $this->view->render('login/index');
 
     }

     function validar(){

        $usuario = $_POST['usuario'];
        $password = $_POST['clave'];

        $query = $this->model->autenticar($usuario,$password);

        if($query){
        //  echo"autenticado";
           
          $this->getUsuarios();
        }else{
            echo"no autenticado";
        }
         

     }

     function getUsuarios($param = null){
       
        $usuarios =  $this->model->getUsuarios();
        $this->view->usuarios = $usuarios;
        $this->view->resultado =  $param[0] ?? null;
        $this->view->render('usuario/index');
        
    }

    function nuevoUsuario(){        

        $roles = $this->model->obtenerRoles();
        $this->view->roles = $roles; 
        $this->view->rolid = '';    
        $epss = $this->model->obtenerEps();
        $this->view->epss = $epss; 
        $this->view->epsid = '';    
    
         $this->view->render('usuario/nuevo');
      }

      
    function RegistrarProducto(){
        $nombre = $_POST['nombre'];
        $documento = $_POST['documento'];
        $password = $_POST['password'];
        $genero = $_POST['genero'];
        $fechaN = $_POST['fechaN'];
        $telefono = $_POST['telefono'];
        $eps = $_POST['eps'];
        $rol = $_POST['rol'];
        $query = $this->model->guardarUsuario($nombre,$documento,$password,$genero,$fechaN,$telefono,$eps,$rol);
        if($query){
          $mensaje= "Datos Actualizados";
          $result=[2];
         }else{
           $mensaje= "Error Datos NO Actualizados";
         }
        $this->view->mensaje=$mensaje; 
        $this->getUsuarios($result);
      }

      function GetUsuario($param = null){

        $id = $param[0];     
        $usuario = $this->model->obtenerUsuarioId($id);
        $roles = $this->model->obtenerRoles();
        $this->view->roles = $roles; 
        $this->view->rolid = $usuario->rol;    
        $epss = $this->model->obtenerEps();
        $this->view->epss = $epss; 
        $this->view->epsid = $usuario->eps;  
        session_start();
        $_SESSION['id'] = $usuario->id;
        $this->view->usuario = $usuario;     
        $this->view->mensaje='';
        $this->view->render('usuario/detalle');
    }

    function ActualizarUsuario(){
     
            session_start();
            $id = $_SESSION['id']; 
            $nombre = $_POST['nombre'];
            $documento = $_POST['documento'];
            $password = $_POST['password'];
            $genero = $_POST['genero'];
            $fechaN = $_POST['fechaN'];
            $telefono = $_POST['telefono'];
            $eps = $_POST['eps'];
            $rol = $_POST['rol'];
            unset($_SESSION['id']);
            //Se Actualizan los datos
            $query = $this->model->updateUsuario($id,$nombre,$documento,$password,$genero,$fechaN,$telefono,$rol,$eps);
            if($query){
              $mensaje= "Datos Actualizados";
              $result=[3];
             }else{
               $mensaje= "Error Datos NO Actualizados";
             }
            $this->view->mensaje=$mensaje; 
            $this->getUsuarios($result);
          }

          function DeleteUsuario($param = null){
            $id =  $param[0]; 
            $query = $this->model->eliminarUsuario($id);
             if($query){
              $mensaje= "Datos eliminados";
             }else{
               $mensaje= "Error Datos NO Eliminados";
             }
          
           echo json_encode($mensaje);
           }
    }

    
?>