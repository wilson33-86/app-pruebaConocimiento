
<?php require "views/header.php"; ?>
<div class="container mt-4">
    <div class="col-12">
        <h2 class="h3 text-center">Usuarios</h2>

      <?php if($this->resultado == 1): ?>
         <div class="alert alert-success" role="alert">
        Usuario Eliminado Correctamente
        </div>
         <?php elseif($this->resultado == 2): ?>
         <div class="alert alert-success" role="alert">
        Usuario Creado Correctamente
        </div>
         <?php elseif($this->resultado == 3): ?>
         <div class="alert alert-success" role="alert">
        Usuario Actualizado Correctamente
        </div>
        
      <?php endif;?>

        <a class="btn btn-success" href="<?php echo constant('URL').'login/nuevoUsuario';?>">Nuevo&nbsp;<i class="fa fa-plus"></i></a>
        <table class="table table-hover">
            <thead>
                <tr>
                  
                    <th>Nombre</th>
                    <th>Documento</th>
                    <th>Genero</th>
                    <th>Edad</th>
                    <th>Telefono</th>
                    <th>Eps</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
           
            <?php foreach($this->usuarios as $usuario):?> 
              <tr id="hijo-<?php echo  $usuario->id;?>">  
              <td><?php echo $usuario->nombre;?></td>
              <td><?php echo $usuario->documento;?></td>
              <td><?php echo $usuario->genero;?></td>
              <td><?php echo $usuario->edad;?></td>
              <td><?php echo $usuario->telefono;?></td>
              <td><?php echo $usuario->eps;?></td>
              <td><?php echo $usuario->rol;?></td>
              <td class="d-flex justify-content-around">
           
             <button class="usuarios btn btn-danger" data-id="<?php echo  $usuario->id;?>" >Eliminar</button>
                <a href="<?php echo constant('URL').'login/GetUsuario/'.$usuario->id;?>" class="btn btn-warning">Actualizar</a>
            </td>
              </tr>
             <?php endforeach; ?>

            </tbody>
        </table>
    </div>
</div>
</section>
    <script src="<?php echo constant('URL').'public/js/appusuarios.js';?>" type="text/javascript">       
    
    </script>
</body>

</html>
