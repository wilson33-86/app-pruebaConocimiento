
<?php require "views/header.php"; ?>
<div class="container mt-4">
    <form class="form col-md-6 col-md-offset-3" action="<?php echo constant('URL');?>login/ActualizarUsuario" method="POST">
        <h2 class="h3">Actualizar Usuario</h2>

        <div class="form-group mb-2">
            <label for="id">Id</label>
            
                <input class="form-control" type="text" placeholder="Nombre" name="id" value="<?php echo $this->usuario->id;?>" required disabled>
        
        </div>

        <div class="form-group mb-2">
            <label for="nombre">Nombre</label>
            
                <input class="form-control" type="text" placeholder="Nombre" name="nombre" value="<?php echo $this->usuario->nombre;?>" required>
        
        </div>
        <div class="form-group mb-2">
            <label for="documento">Documento</label>
            <input class="form-control" type="text" placeholder="documento" name="documento" value="<?php echo $this->usuario->documento;?>"  required>
                           
        </div>
        <div class="form-group mb-4">
            <label for="password">Password</label>
           
                <input  name="password" class="form-control" type="text" placeholder="password" value="<?php echo $this->usuario->password;?>" required>
            
        </div>
         <div class="form-group mb-4">
         <label for="genero">Genero</label>
          <select name="genero" class="form-select" require>
              <option value="">--Seleccione--</option>
               <option value="M">Masculino</option>
               <option value="F">Femenino</option>
           </select>
            
        </div>

        <div class="form-group mb-4">
            <label for="fechaNacimiento">Fecha Nacimiento</label>
           
                <input  name="fechaN" class="form-control" type="date" placeholder="fecha Nacimiento" value="<?php echo $this->usuario->edad;?>" required>
            
        </div>
     
         <div class="form-group mb-4">
            <label for="telefono">Telefono</label>
           
                <input  name="telefono" class="form-control" type="text" placeholder="telefono" value="<?php echo $this->usuario->telefono;?>" required>
            
        </div>

        <div class="form-group mb-4">
             <label for="eps">Eps</label>
            <select name="eps" class="form-select">
              <option value="">--Seleccione--</option>
               <?php foreach($this->epss as $eps):?>
              <option <?php echo $this->epsid === $eps->id ?'selected':'';?> value="<?php echo $eps->id?>"><?php echo $eps->nombre?></option>

              <?php endforeach;?>

   
            </select>          
           
                           
        </div>

        <div class="form-group mb-4">
             <label for="rol">Rol</label>
            <select name="rol" class="form-select">
              <option value="">--Seleccione--</option>
               <?php foreach($this->roles as $rol):?>
              <option <?php echo $this->rolid === $rol->id ?'selected':'';?> value="<?php echo $rol->id?>"><?php echo $rol->nombre?></option>

              <?php endforeach;?>

   
            </select>          
           
                           
        </div>
       
            
                <button  type="submit" class="btn btn-success">Guardar</button>
                <a href="<?php echo constant('URL').'login/getUsuarios';?>" class="btn btn-warning">Volver</a>
            
        
    </form>
</div>

<?php require "views/footer.php"; ?>
