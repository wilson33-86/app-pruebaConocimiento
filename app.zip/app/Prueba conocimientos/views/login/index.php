<?php
include 'views/header.php';
?>
<form class="col-6 m-auto" method="POST" action="<?php echo constant('URL');?>login/validar">
    <h3>Iniciar sesión</h3>
  <div class="mb-3">
    <label for="usuario" class="form-label">Usuario</label>
    <input type="text" class="form-control" id="usuario" name="usuario">
    
  <div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="clave">
  </div>
  
  <button type="submit" class="btn btn-primary">Ingresar</button>
</form>

