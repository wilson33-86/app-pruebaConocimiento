document.addEventListener('DOMContentLoaded',()=>{
    const message = document.querySelectorAll('.alert');
    
    message.forEach(msg=>{
        
        setTimeout(() => {
            msg.remove();
        }, 3000);
    })
})

const usuarios = document.querySelectorAll('.usuarios');
usuarios.forEach(usuario=>{
    usuario.addEventListener('click',()=>{
        // const matricula = this.dataset.id;
        // console.log('click');
        const id =usuario.getAttribute('data-id');
        // console.log(matricula);
       const confirm = window.confirm('Desea borrar el usuario con el id: '+id);

       if(confirm){
         http('http://localhost:8080/Prueba%20conocimientos/login/DeleteUsuario/'+id);
        //  const ulpadre = document.querySelector('#padre');
         const hijo = document.querySelector('#hijo-'+id);
        //  console.log(hijo);
         const papa = hijo.parentElement;
         papa.removeChild(hijo);
       }else{
         return false;
       }

    })
    
});

async function http(url){
    const respuestaRaw = await fetch(url, {
        method: "DELETE",
    });
    const respuesta = await respuestaRaw.json();
    if (respuesta) {
        console.log(respuesta);
        

    }
    
}