<?php
define('URL','http://localhost:8080/Prueba%20conocimientos/');
define('HOST','localhost');
define('USER','root');
define('PASSWORD','');
define('DB','prueba');
define('CHARSET','utf8mb4');


?>